from flask import Flask, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def index():
    return '''<form action="/guardar_datos" method="post">
    <label for="Cedula">Cedula</label>
    <input type="text" id="Cedula" name="Cedula" required><br>
    <label for="Nombre_completo">Nombre Completo</label>
    <input type="text" id="Nombre_completo" name="Nombre_completo" required><br>
    <label for="Email">Email</label>
    <input type="text" id="Email" name="Email" required><br>
    <label for="Telefono">Telefono</label>
    <input type="text" id="Telefono" name="Telefono" required><br>
    <button type="submit" value="Requistrar">Enviar</button>    
    </form>'''

@app.route('/guardar_datos', methods=['POST'])
def guardar_datos():
    cedula = request.form['Cedula']
    print("aaaaaa",cedula)
    nombre_completo = request.form['Nombre_completo']
    email = request.form['Email']
    telefono = request.form['Telefono']
    fecha_hora_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print (fecha_hora_actual)

    # Aqui puedes guardar los datos en una base de datos (archivo txt)
    with open('registro_usuario.csv', 'a') as archivo:
     #archivo.write(f'Cedula: {cedula}, Nombre Completo: {nombre_completo}, Email: {email}, Telefono: {telefono}, Fecha y Hora: {fecha_hora_actual}\n')
     archivo.write(f'{cedula},{nombre_completo},{email},{telefono},{fecha_hora_actual}\n')
    return redirect(url_for('confirmacion', nombre = nombre_completo))

@app.route ('/confirmacion')
def confirmacion():
   nombre = request.args.get('nombre')
   print(nombre)
   return f"<h2>Archivo guardado exitosamente, {nombre}</h2><a href='/'>Volver al formulario</a>"
   


if(__name__ == '__main__'):
   app.run(debug=True);

